Snatcher - русский перевод (PlayStation, uncensored), версия 0.2
https://github.com/andruxaster/snatcher-translated-rus

Русский перевод японской PlayStation-версии Snatcher (Konami, 1996,
SLPS-00154) на основе английского фанперевода pepa (v1.5.1), с картинками,
которые PlayStation-версия цензурирует. Перевод сделан с помощью ИИ.

Нужен ваш собственный образ Snatcher (Japan) в формате redump BIN/CUE:

  Snatcher (Japan).bin
  Size   573702192
  SHA1   e6cd330feb594b3951089da866db1a400f0173f6

Наложение патча (xdelta3, Delta Patcher, MultiPatch или другая оболочка xdelta):

  xdelta3 -d -s "Snatcher (Japan).bin" "Snatcher (Japan) [T-Ru v0.2].xdelta" "Snatcher (Japan) [T-Ru v0.2].bin"

Рядом с полученным .bin положите "Snatcher (Japan) [T-Ru v0.2].cue" из этого архива.
Новый образ больше исходного - так и должно быть.

Результат:

  Snatcher (Japan) [T-Ru v0.2].bin
  SHA1   36d7b90271278af4864c3998e6158aca41d671d9

Картинка из раздевалки (Saturn-оригинал): нет (собрано без диска Saturn)

Это бесплатный фанперевод. Его нельзя продавать или распространять вместе
с образом диска. Snatcher (c) Konami.
